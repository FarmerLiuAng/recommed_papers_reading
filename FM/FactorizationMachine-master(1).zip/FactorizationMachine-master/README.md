# FactorizationMachine

a simple Factorization Machine (regression) demo with MovieLens rating datasets.

## Dataset

https://grouplens.org/datasets/movielens/
http://files.grouplens.org/datasets/movielens/ml-100k.zip
